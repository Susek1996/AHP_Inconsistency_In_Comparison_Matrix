package gui;

import consistency.KoczkodajIndex;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JPanel;

public class Menu extends JPanel implements ActionListener{

    public static int columnsAndRowsDimension; // the same dimension for columns and rows
    private static int lastColumnsAndRowsDimension;
    //myMatrix is the given matrix  (selected by us or chosen randomly)
    //limitMatrix is the limit matrix (consistent)
    public static double myMatrix[][], limitMatrix[][];
    //tempMatrix is an auxiliary matrix
    private static double tempMatrix[][];
    private static JTextField inputField[][];
    //result - variable used for saving the OK/cancel choice (setMatrixDimension)
    private static int result;
    //the main panel with buttons
    private static JPanel choosePanel[] = new JPanel[9];
    private static JButton showMatrix, newMatrix, indKocz, randomMatrix, limit, inconsistencyProcess;
    //public static int max_step;

    //the default Menu constructor
    Menu() {
        columnsAndRowsDimension = 0;
        myMatrix = new double[0][0];
        limitMatrix = new double[0][0];
        ChooseOperation();
    }

    private static void newMatrix(int x) {

        JTextField matrixDimension = new JTextField(5); 

        //design input line
        JPanel choosePanel[] = new JPanel[2];
        choosePanel[0] = new JPanel();
        choosePanel[1] = new JPanel();
        choosePanel[0].add(new JLabel("Enter Dimensions:"));
        choosePanel[1].add(new JLabel("Size:"));
        choosePanel[1].add(matrixDimension);
        choosePanel[1].add(Box.createHorizontalStrut(15)); // a spacer
        //add OK and CANCEL options
        result = JOptionPane.showConfirmDialog(null, choosePanel,
                null, JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        //save last dimensions
        lastColumnsAndRowsDimension = columnsAndRowsDimension;

        //ok option (dimension confirmed)
        if (result == 0) {

            if (matrixDimension.getText().equals(""))
                columnsAndRowsDimension = 0;
            else {
                    if (isInt(matrixDimension.getText())) {
                        columnsAndRowsDimension = Integer.parseInt(matrixDimension.getText());
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Wrong Dimensions");
                        columnsAndRowsDimension = lastColumnsAndRowsDimension;
                    }
            }
            //wrong dimensions
            if (columnsAndRowsDimension < 1) {
                JOptionPane.showConfirmDialog(null, "You entered wrong dimensions",
                        "Error", JOptionPane.PLAIN_MESSAGE);
                columnsAndRowsDimension = lastColumnsAndRowsDimension;
            } else { //right dimensions (int)
                tempMatrix = myMatrix; //saving the current matrix under tempMatrix
                myMatrix = new double[columnsAndRowsDimension][columnsAndRowsDimension];
                 if (x == 0) { //case where we fill the matrix manually
                    if (!setElements(myMatrix, "Fill your new matrix")) //filling the new matrix
                    {
                        myMatrix = tempMatrix;
                    }
                } else if (x == 1) { // case where the matrix is filled randomly
                    if (!setRandomElements(myMatrix, "")) //filling the new matrix
                    {
                        myMatrix = tempMatrix;
                    }
                }
            }
        } else if (result == 1) { //cancel option
            columnsAndRowsDimension = lastColumnsAndRowsDimension;
        }
    }


    private void ChooseOperation() {
        int temp;

        for (temp = 0; temp < choosePanel.length; temp++) {
            choosePanel[temp] = new JPanel();
        }

        JLabel chooseLabel = new JLabel("Choose operation");
        choosePanel[0].add(chooseLabel);
        choosePanel[1].add(Box.createHorizontalStrut(15)); // a spacer
        newMatrix = new JButton("Fill New Matrix");
        newMatrix.setPreferredSize(new Dimension(275, 35));
        newMatrix.addActionListener(this);
        choosePanel[2].add(newMatrix);

        randomMatrix = new JButton("New Random Matrix");
        randomMatrix.setPreferredSize(new Dimension(275, 35));
        randomMatrix.addActionListener(this);
        choosePanel[3].add(randomMatrix);

        showMatrix = new JButton("Show Matrix");
        showMatrix.setPreferredSize(new Dimension(275, 35));
        showMatrix.addActionListener(this);
        choosePanel[4].add(showMatrix);

        indKocz = new JButton("Koczkodaj Index");
        indKocz.setPreferredSize(new Dimension(275, 35));
        indKocz.addActionListener(this);
        choosePanel[5].add(indKocz);

        limit = new JButton("Limit Consistency Matrix");
        limit.setPreferredSize(new Dimension(275, 35));
        limit.addActionListener(this);
        choosePanel[6].add(limit);

        inconsistencyProcess = new JButton("Inconsistency Process");
        inconsistencyProcess.setPreferredSize(new Dimension(275, 35));
        inconsistencyProcess.addActionListener(this);
        choosePanel[7].add(inconsistencyProcess);

        choosePanel[8].add(Box.createHorizontalStrut(15)); // a spacer

        JOptionPane.showConfirmDialog(null, choosePanel, null,
                JOptionPane.CLOSED_OPTION, JOptionPane.PLAIN_MESSAGE);

    }

    public static void showMatrix(double[][] matrix, String title) {
        int temp, temp1;             //temporary variables

        JPanel choosePanel[] = new JPanel[matrix.length + 1];
        choosePanel[0] = new JPanel();
        choosePanel[0].add(new JLabel(title));

        for (temp = 1; temp <= matrix.length; temp++) {
            choosePanel[temp] = new JPanel();


            for (temp1 = 0; temp1 < matrix[0].length; temp1++) {
                if (matrix[temp - 1][temp1] == -0) {
                    matrix[temp - 1][temp1] = 0;
                }
                choosePanel[temp].add(new JLabel(String.format("%.3f", matrix[temp - 1][temp1])));

                if (temp1 < matrix[0].length - 1) {
                    choosePanel[temp].add(Box.createHorizontalStrut(15)); // a spacer
                }

            }//end col loop

        }//end row loop

        if (columnsAndRowsDimension == 0) {
            JOptionPane.showMessageDialog(null, "You haven't entered any matrix");
        } else {

            JOptionPane.showMessageDialog(null, choosePanel, null,
                    JOptionPane.PLAIN_MESSAGE, null);
        }

    }//end show Matrix

    private static boolean setElements(double matrix[][], String title) {
        int temp, temp1;             //temporary variables
        String tempString;

        JPanel choosePanel[] = new JPanel[columnsAndRowsDimension + 2];
        choosePanel[0] = new JPanel();
        choosePanel[0].add(new Label(title));
        choosePanel[choosePanel.length - 1] = new JPanel();
        choosePanel[choosePanel.length - 1].add(new Label("Fill space field as comparison matrix"));
        inputField = new JTextField[matrix.length][matrix.length];


        //lenght loop
        for (temp = 1; temp <= matrix.length; temp++) {
            choosePanel[temp] = new JPanel();


            for (temp1 = 0; temp1 < matrix.length; temp1++) {
                inputField[temp - 1][temp1] = new JTextField(3);
                choosePanel[temp].add(inputField[temp - 1][temp1]);

                if (temp1 < matrix.length - 1) {
                    choosePanel[temp].add(Box.createHorizontalStrut(15)); // a spacer
                }

            }//end col loop

        }//end row loop

        result = JOptionPane.showConfirmDialog(null, choosePanel,
                null, JOptionPane.OK_OPTION, JOptionPane.PLAIN_MESSAGE);


        if (result == 0) {
            checkTextField(inputField);
            for (temp = 0; temp < matrix.length; temp++) {
                for (temp1 = temp; temp1 < matrix.length; temp1++) {
                    tempString = inputField[temp][temp1].getText();

                    if (isDouble(tempString)) {
                        matrix[temp][temp1] = Double.parseDouble(inputField[temp][temp1].getText());
                    } else {
                        JOptionPane.showMessageDialog(null, "You entered wrong elements");

                        //backup
                        columnsAndRowsDimension = lastColumnsAndRowsDimension;

                        return false;
                    }
                }
            }
            for (temp = 0; temp < matrix.length; temp++) {
                matrix[temp][temp] = 1.0;
            }
            for (temp = 0; temp < matrix.length; temp++) {
                for (temp1 = 0; temp1 < temp; temp1++) {
                    tempString = inputField[temp][temp1].getText();

                    if (isDouble(tempString)) {
                        matrix[temp][temp1] = (double) 1 / (Double.parseDouble(inputField[temp1][temp].getText()));
                    } else {
                        JOptionPane.showMessageDialog(null, "You entered wrong elements");

                        //backup
                        columnsAndRowsDimension = lastColumnsAndRowsDimension;

                        return false;
                    }
                }
            }
            return true;
        } else
            return false;


    }//end get Inputs

    private static boolean setRandomElements(double matrix[][], String title) {
        int temp, temp1;             //temporary variables
        String tempString;

        JPanel choosePanel[] = new JPanel[columnsAndRowsDimension+2];
        choosePanel[0] = new JPanel();
        choosePanel[0].add(new Label(title));
        choosePanel[choosePanel.length - 1] = new JPanel();
        choosePanel[choosePanel.length - 1].add(new Label("Click 'Yes' to fill randomly this comparison matrix"));
        inputField = new JTextField[matrix.length][matrix.length];


        //lenght loop
        for (temp = 1; temp <= matrix.length; temp++) {
            choosePanel[temp] = new JPanel();


            for (temp1 = 0; temp1 < matrix.length; temp1++) {
                inputField[temp - 1][temp1] = new JTextField(3);
                choosePanel[temp].add(inputField[temp - 1][temp1]);

                if (temp1 < matrix.length - 1) {
                    choosePanel[temp].add(Box.createHorizontalStrut(15)); // a spacer
                }

            }//end col loop

        }//end row loop

        result = JOptionPane.showConfirmDialog(null, choosePanel,
                null, JOptionPane.OK_OPTION, JOptionPane.PLAIN_MESSAGE);


        Random rand = new Random();
        if (result == 0) {
            checkTextField(inputField);
            for (temp = 0; temp < matrix.length; temp++) {
                for (temp1 = temp; temp1 < matrix.length; temp1++) {
                    double p;
                    do {
                        p = rand.nextDouble() * 9;
                    }
                    while (p < 0.111 || p > 9);
                    String d = Double.toString(p);
                    inputField[temp][temp1].setText(d);

                    if (isDouble(d)) {
                        matrix[temp][temp1] = Double.parseDouble(inputField[temp][temp1].getText());
                    } else {
                        JOptionPane.showMessageDialog(null, "You entered wrong elements");

                        //backup
                        columnsAndRowsDimension = lastColumnsAndRowsDimension;
                        return false;
                    }
                }
            }
            for (temp = 0; temp < matrix.length; temp++) {
                matrix[temp][temp] = 1.0;
            }
            for (temp = 0; temp < matrix.length; temp++) {
                for (temp1 = 0; temp1 < temp; temp1++) {
                    tempString = inputField[temp][temp1].getText();

                    if (isDouble(tempString)) {
                        matrix[temp][temp1] = (double) 1 / (Double.parseDouble(inputField[temp1][temp].getText()));
                    } else {
                        JOptionPane.showMessageDialog(null, "You entered wrong elements");

                        //backup
                        columnsAndRowsDimension = lastColumnsAndRowsDimension;
                        return false;
                    }
                }
            }
            return true;
        } else
            return false;


    }//end get Input

    //for setting spaced fields as zeros
    private static void checkTextField(JTextField field[][]) {
        for (int temp = 0; temp < field.length; temp++) {
            for (int temp1 = 0; temp1 < field[0].length; temp1++) {
                if (field[temp][temp1].getText().equals(""))
                    field[temp][temp1].setText("0");
            }
        }
    }//end reset

    private static boolean isInt(String str) {
        int temp;
        if (str.length() == '0')
            return false;

        for (temp = 0; temp < str.length(); temp++) {
            if (str.charAt(temp) != '+' && str.charAt(temp) != '-'
                    && !Character.isDigit(str.charAt(temp))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isDouble(String str) {
        int temp;
        if (str.length() == '0')
            return false;

        for (temp = 0; temp < str.length(); temp++) {
            if (str.charAt(temp) != '+' && str.charAt(temp) != '-'
                    && str.charAt(temp) != '.'
                    && !Character.isDigit(str.charAt(temp))
            ) {
                return false;
            }
        }
        return true;
    }
    //function for computing Koczkodaj index for given matrix
    private static void koczkodaj() {
        double k = KoczkodajIndex.compute(myMatrix);
        JPanel choosePanel[] = new JPanel[2];
        choosePanel[0] = new JPanel();
        choosePanel[0].add(new JLabel("Inconsistency Ratio "));
        choosePanel[1] = new JPanel();
        choosePanel[1].add(new JLabel(String.format("%.3f", k)));
        JOptionPane.showMessageDialog(null, choosePanel, null,
                JOptionPane.PLAIN_MESSAGE, null);
    }

    private static double[] inconsistencyProcessResults() {
        int tempSize=myMatrix.length;
        double [][] tempMatrix2=new double[tempSize][tempSize];
        for (int i = 0; i < tempSize; i++) {
            for(int j=0;j<tempSize;j++){
             tempMatrix2[i][j]=myMatrix[i][j];
            }

        }
        double koczkodajIndex=KoczkodajIndex.compute(tempMatrix2);
        ArrayList<Double> results=new ArrayList<>();
        results.add(koczkodajIndex);
        int i2 = KoczkodajIndex.i1;
        int j2 = KoczkodajIndex.j1;
        int k2 = KoczkodajIndex.k1;
        do{
            KoczkodajIndex.change(tempMatrix2, i2, j2, k2);
            koczkodajIndex = KoczkodajIndex.compute(tempMatrix2);
            i2 = KoczkodajIndex.i1;
            j2 = KoczkodajIndex.j1;
            k2 = KoczkodajIndex.k1;
            results.add(koczkodajIndex);
        }while (koczkodajIndex > 0.3);
        return results.stream().mapToDouble(Double::doubleValue).toArray();
    }
    public static JScrollPane createPanel(double[] results) {
        int temp;             //temporary variables
        JPanel resultPanel = new JPanel();
        resultPanel.add(new JLabel("Results of inconsistency process: "));
        //resultPanel.setPreferredSize(new Dimension(200,300));
        resultPanel.add(new JLabel("Inital value "+String.format("%.3f", results[0])));
        for (temp = 2; temp <= results.length; temp++) {
            resultPanel.add(new JLabel("After "+(temp-1)+"step "+String.format("%.3f", results[temp-1])));
        }
        resultPanel.setAutoscrolls(true);
        resultPanel.setLayout(new BoxLayout(resultPanel,BoxLayout.Y_AXIS));
        JScrollPane scroll=new JScrollPane(resultPanel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scroll.setPreferredSize(new Dimension(200,500));
        scroll.setEnabled(true);
        scroll.setViewportView(resultPanel);
        scroll.getVerticalScrollBar().setUnitIncrement(30);
        scroll.getHorizontalScrollBar().setUnitIncrement(30);
        if (results.length == 0) {
            JOptionPane.showMessageDialog(null, "You haven't entered any matrix");
        } else {
            JOptionPane.showMessageDialog(null, scroll, null,
                    JOptionPane.PLAIN_MESSAGE, null);
        }

        return scroll;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == showMatrix) {
            showMatrix(myMatrix, "Your Matrix");
        } else if (e.getSource() == newMatrix) {
            newMatrix(0); //x==0 we create manually
        } else if (e.getSource() == randomMatrix) {
            newMatrix(1); //x==1 random matrix
        } else if (e.getSource() == indKocz) {
            koczkodaj();
        } else if (e.getSource() == limit) {
            limitMatrix=KoczkodajIndex.consistencyMatrix(myMatrix);
            showMatrix(limitMatrix, "Consistency Matrix");
        } else if (e.getSource() == inconsistencyProcess) {
            double[] results=inconsistencyProcessResults();
            //for(double x: results)
                //System.out.println(x);
            JScrollPane pane = createPanel(results);

        }


    }


    public static void main(String[] args) {

        Menu m1 = new Menu();

    }
}
