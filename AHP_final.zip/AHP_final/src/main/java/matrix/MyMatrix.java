package matrix;

import Jama.Matrix;
import org.apache.commons.math3.util.Precision;

import java.util.Random;
import java.util.Scanner;

public class MyMatrix {
    public static Matrix create() {
        Scanner s = new Scanner(System.in);

        System.out.print("Put the matrix size: ");
        int size=s.nextInt();

        Matrix matrix = new Matrix(size, size);
        double[][] tmp = matrix.getArray();
        for(int i = 0; i<size; i++)
            for(int j = i; j<size; j++) {
                System.out.print("Put a[" + (i+1) + "][" + (j+1) + "]=");
                tmp[i][j] = s.nextDouble();
            }

        for(int i = 0; i<size; i++)
            tmp[i][i]=1;

        for(int i = 0; i<size; i++)
            for(int j = 0; j<i; j++)
                tmp[i][j] = 1/tmp[j][i];


        return matrix;
    }
    public static  Matrix random(int size) {

        Matrix matrix = new Matrix(size, size);
        double[][] tmp = matrix.getArray();
        Random rand = new Random();
        for(int i = 0; i<size; i++)
            for(int j = i+1; j<size; j++) {
                do {
                    tmp[i][j] = rand.nextDouble()*9;
                }
                while(tmp[i][j]<0.111 || tmp[i][j]>9);
            };

        for(int i = 0; i<size; i++)
            tmp[i][i]=1;

        for(int i = 0; i<size; i++)
            for(int j = 0; j<i; j++)
                tmp[i][j] = 1/tmp[j][i];


        return matrix;
    }
    public static void show(Matrix matrix) {
        double[][] tmp = matrix.getArray();
        for (int i = 0; i < tmp.length; i++) {
            for (int j = 0; j < tmp[i].length; j++) System.out.print(Precision.round(tmp[i][j], 3) + " ");
            System.out.println();
        }

    }
    public static void show(double[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) System.out.print(Precision.round(arr[i][j], 3) + " ");
            System.out.println();
        }

    }
}
