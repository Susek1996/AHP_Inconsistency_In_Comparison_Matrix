package main;

import Jama.Matrix;
import consistency.KoczkodajIndex;
import matrix.MyMatrix;

import java.io.*;
import java.util.ArrayList;

public class CSVforAnalysis {
    public static int MAX=5000;
    public static int step=1;
    public static final double indexLimit=0.3;
    public static final int []tableOfSizes={3,4,5,6,7,8,9,10};
    public static ArrayList<ArrayList<Double>> listOfResultsList = new ArrayList<ArrayList<Double>>();

   public static void toCSV(ArrayList<ArrayList<Double>> listOfResults) throws IOException {
       File file = new File("results.txt");
       FileWriter fileWriter = new FileWriter(file,false);
       BufferedWriter writer = new BufferedWriter(fileWriter);
       for(ArrayList<Double> singleList: listOfResults) {
           for (int i = 0; i < singleList.size(); i++) {
               writer.append(","+Double.toString(singleList.get(i)));
           }
           writer.newLine();
       }
        writer.close();
   }
    public static void main(String[] args) {

        try {
            for (int size : tableOfSizes)
                for (int i = 0; i < 10; i++) {
                    randomMatrix(size);
                    step = 1;
                }
            toCSV(listOfResultsList);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static ArrayList<Double> randomMatrix(int size) {
        ArrayList<Double> singleListOfResults = new ArrayList<Double>();
        singleListOfResults.add(Double.valueOf(size));
        double k;
        Matrix m = MyMatrix.random(size);
        k = KoczkodajIndex.compute(m);
        singleListOfResults.add(k);
        int i2 = KoczkodajIndex.i1;
        int j2 = KoczkodajIndex.j1;
        int k2 = KoczkodajIndex.k1;

        if (!(k <= indexLimit))
            {
            do {
                KoczkodajIndex.change(m, i2, j2, k2);
                k = KoczkodajIndex.compute(m);
                singleListOfResults.add(k);
                i2 = KoczkodajIndex.i1;
                j2 = KoczkodajIndex.j1;
                k2 = KoczkodajIndex.k1;
                step++;
            }
            while (k > indexLimit && step!=MAX);
            step--;
            singleListOfResults.add(1,Double.valueOf(step));
            listOfResultsList.add(singleListOfResults);
        }
        return singleListOfResults;
    }


}
