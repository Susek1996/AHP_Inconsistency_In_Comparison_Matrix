package consistency;

import Jama.Matrix;

public class KoczkodajIndex {
    public static int i1;
    public static int j1;
    public static int k1;
    static public double compute(Matrix matrix) {
        int n = matrix.getRowDimension();
        double max = 0;
        for (int i = 0; i < n - 2; i++)
            for (int j = i + 1; j < n - 1; j++)
                for (int k = j + 1; k < n; k++) {
                    double tmp = (1 - Math.exp(-Math.abs(Math.log(matrix.get(i, k) / (matrix.get(i, j) * matrix.get(j, k))))));
                    if (tmp > max) {
                        max = tmp;
                        i1=i;
                        j1=j;
                        k1=k;
                    }


                }
        return max;
    }
    static public double compute(double matrix[][]) {
        int n = matrix.length;
        double max = 0;
        for (int i = 0; i < n - 2; i++)
            for (int j = i + 1; j < n - 1; j++)
                for (int k = j + 1; k < n; k++) {
                    double tmp = (1 - Math.exp(-Math.abs(Math.log(matrix[i][k] / (matrix[i][j] * matrix[j][k])))));
                    if (tmp > max) {
                        max = tmp;
                        i1=i;
                        j1=j;
                        k1=k;
                    }


                }
        return max;
    }
    static public Matrix change(Matrix matrix,int i,int k,int j){
        double new_ik,new_ij,new_kj;
        new_ik=Math.pow(matrix.get(i,k),2.0/3.0)*Math.pow(matrix.get(i,j),1.0/3.0)*Math.pow(matrix.get(k,j),-1.0/3.0);
        new_ij=Math.pow(matrix.get(i,k),1.0/3.0)*Math.pow(matrix.get(i,j),2.0/3.0)*Math.pow(matrix.get(k,j),1.0/3.0);
        new_kj=Math.pow(matrix.get(i,k),-1.0/3.0)*Math.pow(matrix.get(i,j),1.0/3.0)*Math.pow(matrix.get(k,j),2.0/3.0);
        matrix.set(i,k,new_ik);
        matrix.set(k,i,1/new_ik);
        matrix.set(i,j,new_ij);
        matrix.set(j,i,1/new_ij);
        matrix.set(k,j,new_kj);
        matrix.set(j,k,1/new_kj);


        return matrix;
    }
    static public double[][] change(double matrix[][],int i,int k,int j){
        double new_ik,new_ij,new_kj;
        new_ik=Math.pow(matrix[i][k],2.0/3.0)*Math.pow(matrix[i][j],1.0/3.0)*Math.pow(matrix[k][j],-1.0/3.0);
        new_ij=Math.pow(matrix[i][k],1.0/3.0)*Math.pow(matrix[i][j],2.0/3.0)*Math.pow(matrix[k][j],1.0/3.0);
        new_kj=Math.pow(matrix[i][k],-1.0/3.0)*Math.pow(matrix[i][j],1.0/3.0)*Math.pow(matrix[k][j],2.0/3.0);
        matrix[i][k]=new_ik;
        matrix[k][i]=1/new_ik;
        matrix[i][j]=new_ij;
        matrix[j][i]=1/new_ij;
        matrix[k][j]=new_kj;
        matrix[j][k]=1/new_kj;


        return matrix;
    }
    //function to compute the vector of geometric mean of i-th row
    static public double vector(double matrix[][], int i){
        int n = matrix.length;
        double gmean=1; //srednia geometryczna
        double temp=1;
        for(int j=0;j<n;j++)
        {
            temp=temp*matrix[i][j];
        }
        gmean=Math.pow(temp,1.0/n);
        return gmean;
    }
    //function to create the limit consistency Matrix
    static public double[][] consistencyMatrix(double matrix[][]){
        int n=matrix.length;
        double[][] temp=new double [n][n];
        for(int k=0;k<n;k++)
        {
            for(int m=0;m<n;m++)
            {
             temp[k][m]=vector(matrix,k)/vector(matrix,m);
            }
        }
        return temp;
    }

}
